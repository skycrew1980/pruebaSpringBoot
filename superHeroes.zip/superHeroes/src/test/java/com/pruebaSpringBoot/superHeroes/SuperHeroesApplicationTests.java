package com.pruebaSpringBoot.superHeroes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuperHeroesApplicationTests {

	@Test
	void contextLoads() {
	}

}
