package com.pruebaSpringBoot.superHeroes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SuperHeroesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SuperHeroesApplication.class, args);
	}

}
